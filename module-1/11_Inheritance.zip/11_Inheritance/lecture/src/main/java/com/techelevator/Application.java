package com.techelevator;

import java.util.ArrayList;

public class Application {

    public static void main(String[] args) {

        // Create a new general auction
        System.out.println("Starting a general auction");
        System.out.println("-----------------");

        Auction generalAuction = new Auction("Tech Elevator t-shirt");

        generalAuction.placeBid(new Bid("Josh", 1));
        generalAuction.placeBid(new Bid("Fonz", 23));
        generalAuction.placeBid(new Bid("Rick Astley", 13));
        //....
        //....
        // This might go on until the auction runs out of time or hits a max # of bids

        raAuction.placeBid( new Bid( "Bob", 15));

        BuyoutAuction boAuction = new BuyoutAuction( "TE Yeti Mug", 25);

        braAuction.placeBid(new Bid( "Bob", 250


        List<Auction> allAuctions = new ArrayList<>();

        allAuctions.add(generalAuction);
        allAuctions.add(boAuction);
        allAuctions.add(raAuction);

        for(Auction auction : allAuctions){
            System.out.println("****************");
            System.out.println(auction.getItemForSale());
            System.out.println("*****************");
            System.out.println("Current Winner is: " + auction.getHighBid().getBidder());

            System.out.println("---------Bid");
        }

    }
}
