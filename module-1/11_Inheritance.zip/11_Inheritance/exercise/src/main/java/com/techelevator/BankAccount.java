package com.techelevator;

public class BankAccount {
    public static final int DEFAULT_STARTING_BALANCE = 0;

    private String accountHolderName;
    private String accountNumber;
    private int balance ;

    public BankAccount(String accountHolderName, String accountNumber) {
        this.accountHolderName = accountHolderName;
        this.accountNumber = accountNumber;
    }
    public void deposit(){
        this.deposit(DEFAULT_STARTING_BALANCE);
    }
    public void deposit(int amountToDeposit){
        int currentBalance = 0;
    }
}
